//
//  DisplayRatingsViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/8/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit

var floorLevels = ["1", "2", "3"]

class DisplayRatingsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var buildingName: UILabel!
    @IBOutlet weak var noiseSlider: UISlider!
    @IBOutlet weak var occupancySlider: UISlider!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var tableView: UITableView!
    
    var locName = String()
    var noiseLevel:Int?
    var occupancyLevel:Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        tableView.delegate = self
        tableView.dataSource = self
        
        print("location name = \(locName)")
        buildingName.text! = locName
        
        setPic()
        setNoiseSlider()
        setOccupancySlider()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(textCellIdentifier, forIndexPath: indexPath)
        
        let row = indexPath.row
        
        cell.textLabel?.text = ("Floor Level \(row+1)")
        cell.textLabel?.textColor = UIColor.orangeColor()
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let row = indexPath.row
        print(floorLevels[row])
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if  segue.identifier == "floorLvlSegue",
            let vc = segue.destinationViewController as? FloorLevelViewController,
            index = tableView.indexPathForSelectedRow?.row {
            vc.floorName = floorLevels[index]
            vc.building = locName
        }
    }
    
    func setPic() {
        
        if locName == "Student Activity Center (SAC)" {
            imageView.image = UIImage(named: "sac")
            descriptionLabel.text = "The sac is located in the middle of campus"
        }
        else if locName == "Flawn Academic Center (FAC)" {
                imageView.image = UIImage(named: "fac")
                descriptionLabel.text = "The sac is located in the middle of campus"
        }
        else if locName == "Perry-Castaneda Library (PCL)" {
            imageView.image = UIImage(named: "pcl")
            descriptionLabel.text = "The sac is located in the middle of campus"
        }
        else if locName == "Union Building (UNB)" {
            imageView.image = UIImage(named: "union")
            descriptionLabel.text = "The sac is located in the middle of campus"
        }
        else if locName == "Gates Dell Complex (GDC)" {
            imageView.image = UIImage(named: "gdc")
            descriptionLabel.text = "The sac is located in the middle of campus"
        }
        else if locName == "Robert Lee Moore Hall (RLM)" {
            imageView.image = UIImage(named: "sac")
            descriptionLabel.text = "The sac is located in the middle of campus"
        }
        else if locName == "Liberal Arts Building (CLA)" {
            imageView.image = UIImage(named: "cla")
            descriptionLabel.text = "The sac is located in the middle of campus"
        }
        else if locName == "Norman Hackerman Building (NHB)" {
            imageView.image = UIImage(named: "nhb")
            descriptionLabel.text = "The sac is located in the middle of campus"
        }
        else if locName == "Student Services Building (SSB)" {
            imageView.image = UIImage(named: "ssb")
            descriptionLabel.text = "The sac is located in the middle of campus"
        }
        else if locName == "Robert A. Welch Hall (WEL)" {
            imageView.image = UIImage(named: "ssb")
            descriptionLabel.text = "The sac is located in the middle of campus"
        }
        
    }
    
    func setNoiseSlider() {
        noiseSlider.minimumValue = 0
        noiseSlider.maximumValue = 9
        noiseSlider.value = 3
        
        if noiseSlider.value >= 0 && noiseSlider.value < 4 {
            noiseSlider.minimumTrackTintColor = UIColor.greenColor()
        }
        else if noiseSlider.value >= 4 && noiseSlider.value < 7 {
            noiseSlider.minimumTrackTintColor = UIColor.yellowColor()
        }
        else {
            noiseSlider.minimumTrackTintColor = UIColor.redColor()
        }
    }
    
    func setOccupancySlider() {
        occupancySlider.minimumValue = 0
        occupancySlider.maximumValue = 9
        occupancySlider.value = 8
        
        if occupancySlider.value >= 0 && occupancySlider.value < 4 {
            occupancySlider.minimumTrackTintColor = UIColor.greenColor()
        }
        else if occupancySlider.value >= 4 && occupancySlider.value < 7 {
            occupancySlider.minimumTrackTintColor = UIColor.yellowColor()
        }
        else {
            occupancySlider.minimumTrackTintColor = UIColor.redColor()
        }
    }
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
