//
//  DisplayRatingsViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/8/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit

var floorLevels = ["1", "2", "3"]

class DisplayRatingsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {


    @IBOutlet weak var tableView: FloorLevel!
    @IBOutlet weak var buildingName: UILabel!
    @IBOutlet weak var noiseProgress: UIProgressView!
    @IBOutlet weak var occupancyProgress: UIProgressView!
    
    var locName = String()
    var noiseLevel:Int?
    var occupancyLevel:Int?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        tableView.delegate = self
        tableView.dataSource = self
        
        print("location name = \(locName)")
        buildingName.text! = locName
        
        /*if locName == "Student Activity Center (SAC)" {
            //imageView = UIImageView(frame: CGRectMake(100, 150, 150, 150));
            imageView.image = UIImage(named: "sac")
            locationDescription.text = "The sac is located in the middle of campus"
        }*/
        
        //occupancyProgress.setProgress(Float(occupancyLevel!), animated: false)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 3
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(textCellIdentifier, forIndexPath: indexPath)
        
        let row = indexPath.row
        
        cell.textLabel?.text = ("floor level \(row+1)")
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let row = indexPath.row
        print(floorLevels[row])
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if segue.identifier == "enterRatingsSegue"{
            let vc = segue.destinationViewController as! InputRatingViewController
            vc.ratings = self
        }
    }
    
    func updateRating() {
        noiseProgress.setProgress(Float(noiseLevel!), animated: false)
        occupancyProgress.setProgress(Float(occupancyLevel!), animated: false)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
