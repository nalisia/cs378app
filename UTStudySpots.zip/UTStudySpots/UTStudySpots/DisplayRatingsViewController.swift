//
//  DisplayRatingsViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/8/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit
import CoreData
import Alamofire

var floorLevels = ["1", "2", "3"]

class DisplayRatingsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UpdatedDataPlace {

    @IBOutlet weak var buildingName: UILabel!
    @IBOutlet weak var noiseSlider: UISlider!
    @IBOutlet weak var occupancySlider: UISlider!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var noiseRating: UILabel!
    @IBOutlet weak var occupancyRating: UILabel!
    
    @IBOutlet weak var tableView: UITableView!
    
    var location: NSManagedObject! = nil
    var noiseLevel:Int?
    var occupancyLevel:Int?
    var locName = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        tableView.delegate = self
        tableView.dataSource = self
        let name = location.valueForKey("name")! as! String
        
        let acro = location.valueForKey("acronym")
        locName = "\(name) (\(acro!))"
        print("location name = \(locName)")
        buildingName.text! = locName
        
        setPic()
        fetchRatings()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let numOfFloor:Int = Int(location.valueForKey("floors")! as! NSNumber)
        return numOfFloor
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(textCellIdentifier, forIndexPath: indexPath)
        
        let row = indexPath.row
        
        cell.textLabel?.text = ("Floor Level \(row+1)")
        cell.textLabel?.textColor = UIColor.orangeColor()
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let row = indexPath.row
        print(floorLevels[row])
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if  segue.identifier == "floorLvlSegue",
            let vc = segue.destinationViewController as? FloorLevelViewController,
            index = tableView.indexPathForSelectedRow?.row {
            vc.location = location
            vc.floorName = index+1
            vc.delegate = self
        }
    }
    
    func setPic() {
        
        if locName == "Student Activity Center (SAC)" {
            imageView.image = UIImage(named: "sac")
            descriptionLabel.text = "The sac is located in the middle of campus"
        }
        else if locName == "Flawn Academic Center (FAC)" {
                imageView.image = UIImage(named: "fac")
                descriptionLabel.text = "The fac is located in the middle of campus"
        }
        else if locName == "Perry-Castaneda Library (PCL)" {
            imageView.image = UIImage(named: "pcl")
            descriptionLabel.text = "The pcl is located in the middle of campus"
        }
        else if locName == "Union Building (UNB)" {
            imageView.image = UIImage(named: "union")
            descriptionLabel.text = "The union is located in the middle of campus"
        }
        else if locName == "Gates Dell Complex (GDC)" {
            imageView.image = UIImage(named: "gdc")
            descriptionLabel.text = "The gdc is located in the middle of campus"
        }
        else if locName == "Robert Lee Moore Hall (RLM)" {
            imageView.image = UIImage(named: "rlm")
            descriptionLabel.text = "The rlm is located in the middle of campus"
        }
        else if locName == "Liberal Arts Building (CLA)" {
            imageView.image = UIImage(named: "cla")
            descriptionLabel.text = "The cla is located in the middle of campus"
        }
        else if locName == "Norman Hackerman Building (NHB)" {
            imageView.image = UIImage(named: "nhb")
            descriptionLabel.text = "The nhb is located in the middle of campus"
        }
        else if locName == "Student Services Building (SSB)" {
            imageView.image = UIImage(named: "ssb")
            descriptionLabel.text = "The ssb is located in the middle of campus"
        }
        else if locName == "Robert A. Welch Hall (WEL)" {
            imageView.image = UIImage(named: "wel")
            descriptionLabel.text = "The wel is located in the middle of campus"
        }
        
    }
    
    func mySetNoiseSlider(avg:float_t) {
        noiseSlider.minimumValue = 0
        noiseSlider.maximumValue = 9
        noiseSlider.value = avg
        
        noiseRating.text = "Noise Level = \(avg)"
        
        if noiseSlider.value >= 0 && noiseSlider.value < 4 {
            noiseSlider.minimumTrackTintColor = UIColor.greenColor()
        }
        else if noiseSlider.value >= 4 && noiseSlider.value < 7 {
            noiseSlider.minimumTrackTintColor = UIColor.yellowColor()
        }
        else {
            noiseSlider.minimumTrackTintColor = UIColor.redColor()
        }
    }
    
    func mySetOccupancySlider(avg:float_t) {
        occupancySlider.minimumValue = 0
        occupancySlider.maximumValue = 9
        occupancySlider.value = avg
        
        occupancyRating.text = "Occupancy Level = \(avg)"
        
        if occupancySlider.value >= 0 && occupancySlider.value < 4 {
            occupancySlider.minimumTrackTintColor = UIColor.greenColor()
        }
        else if occupancySlider.value >= 4 && occupancySlider.value < 7 {
            occupancySlider.minimumTrackTintColor = UIColor.yellowColor()
        }
        else {
            occupancySlider.minimumTrackTintColor = UIColor.redColor()
        }
    }
    func notify(mess: String) {
        print(mess)
        fetchRatings()
    }
    
    func fetchRatings() {
        Alamofire.request(
            .GET,
            "http://107.170.39.244:3000/place",
            parameters: ["include_docs": "true", "id": Int(location.valueForKey("id")! as! NSNumber)],
            encoding: .URL)
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else {
                    print("Error while fetching register: \(response.result.error)")
                    return
                }
                
                guard let value = response.result.value as? [String: AnyObject]
                    else {
                        print("didn't get anything")
                        return
                }
                print(value["averageNoise"]!)
                self.mySetNoiseSlider(Float(value["averageNoise"]! as! NSNumber))
                self.mySetOccupancySlider(Float(value["averageOccupation"]! as! NSNumber))
        }
    }

   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
