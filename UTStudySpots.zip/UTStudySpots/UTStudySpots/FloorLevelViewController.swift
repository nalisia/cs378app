//
//  FloorLevelViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/18/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit
import CoreData
import Alamofire

protocol UpdatedDataPlace{
    func notify(mess:String)
}
class FloorLevelViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, UpdatedData {

    @IBOutlet weak var floorLvl: UILabel!
    @IBOutlet weak var noiseSlider: UISlider!
    @IBOutlet weak var occupancySlider: UISlider!
    @IBOutlet weak var noiseRating: UILabel!
    @IBOutlet weak var occupancyRating: UILabel!
    @IBOutlet weak var tableView: UITableView!

    
    var floorName = 0
    var building = String()
    var location: NSManagedObject! = nil

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
        floorLvl.text! = "\(location.valueForKey("name")!) Floor Level: \(floorName)"
        fetchRatings()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("comment", forIndexPath: indexPath)
        
        let row = indexPath.row
        
        cell.textLabel?.text = ("comment \(row + 1)")
        cell.detailTextLabel?.text = ("Name: 3:00")
        cell.textLabel?.textColor = UIColor.orangeColor()
        
        return cell
    }

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if segue.identifier == "enterRatingSegue" {
            if let vc = segue.destinationViewController as? InputRatingViewController {
              vc.floorId = floorId
                vc.delegate = self
                
                
            }
        }
        /*else if segue.identifier == "loginSegue" {
         if let vc = segue.destinationViewController as? LocationListViewController {
         
         }
         }*/
    }
    var delegate: UpdatedDataPlace?
    func datasaved(mess:String){
        if let del = delegate{
            del.notify(mess)
        }
        
    }
    func notify(mess: String) {
        print(mess)
        fetchRatings()
        datasaved("Data calculated and saved")
        
    }
    func mySetNoiseSlider(avg:float_t) {
        noiseSlider.minimumValue = 0
        noiseSlider.maximumValue = 9
        noiseSlider.value = avg
        
        noiseRating.text = "Noise Level = \(avg)"
        
        if noiseSlider.value >= 0 && noiseSlider.value < 4 {
            noiseSlider.minimumTrackTintColor = UIColor.greenColor()
        }
        else if noiseSlider.value >= 4 && noiseSlider.value < 7 {
            noiseSlider.minimumTrackTintColor = UIColor.yellowColor()
        }
        else {
            noiseSlider.minimumTrackTintColor = UIColor.redColor()
        }
    }
    
    func mySetOccupancySlider(avg:float_t) {
        occupancySlider.minimumValue = 0
        occupancySlider.maximumValue = 9
        occupancySlider.value = avg
        
        occupancyRating.text = "Occupancy Level = \(avg)"
        
        if occupancySlider.value >= 0 && occupancySlider.value < 4 {
            occupancySlider.minimumTrackTintColor = UIColor.greenColor()
        }
        else if occupancySlider.value >= 4 && occupancySlider.value < 7 {
            occupancySlider.minimumTrackTintColor = UIColor.yellowColor()
        }
        else {
            occupancySlider.minimumTrackTintColor = UIColor.redColor()
        }
    }
    var floorId = 0
    func fetchRatings() {
        Alamofire.request(
            .GET,
            "http://107.170.39.244:3000/floor",
            parameters: ["include_docs": "true", "locationName": location.valueForKey("name")! as! String, "floorLevel": floorName],
            encoding: .URL)
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else {
                    print("Error while fetching register: \(response.result.error)")
                    return
                }
                
                guard let value = response.result.value as? [String: AnyObject]
                    else {
                        print("didn't get anything")
                        return
                }
                print(value["averageNoise"]!)
                self.floorId = Int(value["_id"]! as! NSNumber)
                self.mySetNoiseSlider(Float(value["averageNoise"]! as! NSNumber))
                self.mySetOccupancySlider(Float(value["averageOccupation"]! as! NSNumber))
        }
    }




    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
