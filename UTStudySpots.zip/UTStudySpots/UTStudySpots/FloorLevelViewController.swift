//
//  FloorLevelViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/18/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit

class FloorLevelViewController: UIViewController {

    @IBOutlet weak var floorLvl: UILabel!
    @IBOutlet weak var noiseSlider: UISlider!
    @IBOutlet weak var occupancySlider: UISlider!
    
    var floorName = String()
    var building = String()

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        floorLvl.text! = "\(building) Floor Level: \(floorName)"
        
        setNoiseSlider()
        setOccupancySlider()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setNoiseSlider() {
        noiseSlider.minimumValue = 0
        noiseSlider.maximumValue = 9
        noiseSlider.value = 4
        
        if noiseSlider.value >= 0 && noiseSlider.value < 4 {
            noiseSlider.minimumTrackTintColor = UIColor.greenColor()
        }
        else if noiseSlider.value >= 4 && noiseSlider.value < 7 {
            noiseSlider.minimumTrackTintColor = UIColor.yellowColor()
        }
        else {
            noiseSlider.minimumTrackTintColor = UIColor.redColor()
        }
    }
    
    func setOccupancySlider() {
        occupancySlider.minimumValue = 0
        occupancySlider.maximumValue = 9
        occupancySlider.value = 8
        
        if occupancySlider.value >= 0 && occupancySlider.value < 4 {
            occupancySlider.minimumTrackTintColor = UIColor.greenColor()
        }
        else if occupancySlider.value >= 4 && occupancySlider.value < 7 {
            occupancySlider.minimumTrackTintColor = UIColor.yellowColor()
        }
        else {
            occupancySlider.minimumTrackTintColor = UIColor.redColor()
        }
    }



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
