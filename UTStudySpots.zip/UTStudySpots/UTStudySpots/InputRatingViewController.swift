//
//  InputRatingViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/8/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit

class InputRatingViewController: UIViewController {
    @IBOutlet weak var noiseLevelSegment: UISegmentedControl!
    @IBOutlet weak var occupancyLevelSegment: UISegmentedControl!
    @IBOutlet weak var comment: UITextView!
    @IBOutlet weak var saveLabel: UILabel!
    
    var getNoiseSegment:Int?
    var getOccupancySegment:Int?
    var commentText:String?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func saveButton(sender: AnyObject) {
        getNoiseSegment = noiseLevelSegment.selectedSegmentIndex
        getOccupancySegment = occupancyLevelSegment.selectedSegmentIndex
        
        commentText = comment.text!
        
        saveLabel.text! = "Data saved!"
        
        print("noise = \(getNoiseSegment) occupancy = \(getOccupancySegment) comment = \(commentText)")
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Called when the user touches on the main view (outside the UITextField).
    //
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
