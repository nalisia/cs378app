//
//  ViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/8/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit
import Alamofire
import CoreData
import Foundation

class ViewController: UIViewController, UIPopoverPresentationControllerDelegate {

    @IBOutlet weak var usernameText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var loginLabel: UILabel!
    var loginsuccess = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        saveLocs()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
       
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
            if identifier == "loginSegue" {
                if usernameText.text == "" && passwordText.text == "" || usernameText.text == "" || passwordText.text == "" || usernameText.text?.rangeOfString("@utexas.edu") == nil {
                    loginLabel.text = "Please enter a utexas email address"
                    return false
                }
                    //fetchlogin()
                    return loginsuccess
                
                
            }
        
        return true
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if segue.identifier == "registerSegue" {
            if let vc = segue.destinationViewController as? RegisterViewController {
                vc.modalPresentationStyle = UIModalPresentationStyle.Popover
                vc.popoverPresentationController!.delegate = self
                vc.preferredContentSize = CGSize(width: 500, height: 500)
            }
        }
    }
    
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        return .None
    }
    
    @IBAction func loginPressed(sender: AnyObject) {
        fetchlogin()
    }

    func fetchlogin() {
        Alamofire.request(
            .GET,
            /*"http://107.170.39.244:3000/login/\(usernameText.text!)/\(passwordText.text!)"*/
            "http://5e5f6854.ngrok.io/login",
            parameters: ["include_docs": "true", "email" : usernameText.text!, "password" : passwordText.text!],
            encoding: .URL)
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else {
                    print("Error while fetching login: \(response.result.error)")
                    return
                }
                
                guard let value = response.result.value as? [String: AnyObject]
                    else {
                        print("didn't get anything")
                        return
                }
                self.loginsuccess = value["success"]! as! String == "YES"
                    self.performSegueWithIdentifier("loginSegue", sender: self)
                
                print(value["success"]!)
        }

    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Called when the user touches on the main view (outside the UITextField).
    //
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    //-----------------
    // Core Data Stuff
    //-----------------
    
    func saveLocs(){
        let place1 = ["id" : 1, "placeName" : "Student Activity Center", "acronym" : "SAC", "floors" : 3, "desc" : ""]
        let place2 = ["id" : 2, "placeName" : "Flawn Academic Center", "acronym" : "FAC", "floors" : 6, "desc" : ""]
        let place3 = ["id" : 3, "placeName" : "Perry-Castaneda Library", "acronym" : "PCL", "floors" : 6, "desc" : ""]
        let place4 = ["id" : 4, "placeName" : "Union Building", "acronym": "UNB", "floors" : 5, "desc" : ""]
        let place5 = ["id" : 5, "placeName" : "Gates Dell Complex", "acronym" : "GDC", "floors" : 7, "desc" : ""]
        let place6 = ["id" : 6, "placeName" : "Robert Lee Moore Hall", "acronym" : "RLM", "floors" : 10, "desc" : ""]
        let place7 = ["id" : 7, "placeName" : "Liberal Arts Building", "acronym" : "CLA", "floors" : 5, "desc" : ""]
        let place8 = ["id" : 8, "placeName" : "Robert A. Welch Hall", "acronym" : "WEL", "floors" : 7, "desc" : ""]
        let place9 = ["id" : 9, "placeName" : "Norman Hackerman Building", "acronym" : "NHB", "floors" : 9, "desc" : ""]
        let place10 = ["id" : 10, "placeName" : "Student Services Building", "acronym" : "GDC", "floors" : 6, "desc" : ""]
        
        let places = [place1,place2,place3,place4,place5,place6,place7,place8,place9,place10]
        // Check/update all locations in coreData
        let retrievedData = retrieveLocs()
        
        if retrievedData.count != 10{
            clearCoreData()
        }
        if retrievedData.count == 0{
            for location in places{
                storeLoc(location)
            }
        }
        else {
            for location in retrievedData{
                print (location.valueForKey("name"))
            }
            print("data already exists")
        }
    }
    
    func storeLoc(location:[String:AnyObject]){
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        
        // Create the entity we want to save
        let entity =  NSEntityDescription.entityForName("UTPlace", inManagedObjectContext: managedContext)
        let places = NSManagedObject(entity: entity!, insertIntoManagedObjectContext:managedContext)
        
        // Set the attribute values
        places.setValue(location["id"], forKey: "id")
        places.setValue(location["placeName"], forKey: "name")
        places.setValue(location["acronym"], forKey: "acronym")
        places.setValue(location["floors"], forKey: "floors")
        places.setValue(location["desc"], forKey: "desc")
        
        do {
            print("saving to core")
            try managedContext.save()
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        let retrieved = retrieveLocs()
        for place in retrieved {
            if let name = place.valueForKey("name") {
                if let acronym = place.valueForKey("acronym") {
                    print("First Name: \(name), Last Name: \(acronym)")
                }
            }
        }
    }

    func clearCoreData() {
        
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        let fetchRequest = NSFetchRequest(entityName: "UTPlace")
        var fetchedResults:[NSManagedObject]
        
        do {
            try fetchedResults = managedContext.executeFetchRequest(fetchRequest) as! [NSManagedObject]
            
            if fetchedResults.count > 0 {
                
                for result:AnyObject in fetchedResults {
                    managedContext.deleteObject(result as! NSManagedObject)
                    print("\(result.valueForKey("name")!) has been Deleted")
                }
            }
            try managedContext.save()
            
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
    }
    
    func retrieveLocs() -> [NSManagedObject] {
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        let fetchRequest = NSFetchRequest(entityName:"UTPlace")
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = managedContext.executeFetchRequest(fetchRequest) as? [NSManagedObject]
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        return(fetchedResults)!
    }


}

