//
//  ViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/8/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIPopoverPresentationControllerDelegate {

    @IBOutlet weak var usernameText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
       
    override func shouldPerformSegueWithIdentifier(identifier: String, sender: AnyObject?) -> Bool {
            if identifier == "loginSegue" {
                if usernameText.text == "" && passwordText.text == "" || usernameText.text == "" || passwordText.text == "" {
                    return false
                }
            }
        
        return true
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if segue.identifier == "registerSegue" {
            if let vc = segue.destinationViewController as? RegisterViewController {
                vc.modalPresentationStyle = UIModalPresentationStyle.Popover
                vc.popoverPresentationController!.delegate = self
                vc.preferredContentSize = CGSize(width: 500, height: 500)
            }
        }
        /*else if segue.identifier == "loginSegue" {
            if let vc = segue.destinationViewController as? LocationListViewController {
                
            }
        }*/
    }
    
    func adaptivePresentationStyleForPresentationController(controller: UIPresentationController) -> UIModalPresentationStyle {
        return .None
    }



}

