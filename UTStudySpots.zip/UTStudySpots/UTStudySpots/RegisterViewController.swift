//
//  RegisterViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/8/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit
import Alamofire

class RegisterViewController: UIViewController {

    @IBOutlet weak var emailText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var registerStatus: UILabel!
    @IBOutlet weak var firstNameText: UITextField!
    @IBOutlet weak var lastNameText: UITextField!
    var loginsuccess = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func alreadyRegister(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }

    @IBAction func registerButtonPressed(sender: AnyObject) {
        
        if emailText.text == "" || passwordText.text == "" || firstNameText.text == "" || lastNameText == "" {
            registerStatus.text! = "Please fill in everything"
        }
        else if emailText.text?.rangeOfString("@utexas.edu") == nil {
            registerStatus.text! = "Please enter a utexas email and password"
        } else{
            fetchRegister()
        }
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // Called when the user touches on the main view (outside the UITextField).
    //
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func fetchRegister() {
        Alamofire.request(
            .GET,
            "http://107.170.39.244:3000/register"
            /*"http://5e5f6854.ngrok.io/register"*/,
            parameters: ["include_docs": "true", "email" : emailText.text!, "password" : passwordText.text!, "firstname" : firstNameText.text!, "lastname": lastNameText.text!],
            encoding: .URL)
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else {
                    print("Error while fetching register: \(response.result.error)")
                    return
                }
                
                guard let value = response.result.value as? [String: AnyObject]
                    else {
                        print("didn't get anything")
                        return
                }
                
                print(value["success"]!)
                self.loginsuccess = value["success"]! as! String == "YES"
                if self.loginsuccess {
                    self.registerStatus.text! = "Registered!"
                    self.dismissViewControllerAnimated(true, completion: nil)
                    
                }
                else {
                    self.registerStatus.text! = "Username already registered"
                }
                
                print("email is \(self.emailText.text) password is \(self.passwordText.text)")
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
