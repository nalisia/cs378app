//
//  RegisterViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/8/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit
import Alamofire

class RegisterViewController: UIViewController {

    @IBOutlet weak var emailText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var registerStatus: UILabel!
    var loginsuccess = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func registerButtonPressed(sender: AnyObject) {
        //fetchRegister()
        
        if emailText.text == "" && passwordText.text == "" || emailText.text == "" || passwordText.text == "" {
            registerStatus.text! = "Please enter an email and password"
        }
        else {
        registerStatus.text! = "Registered!"
        self.dismissViewControllerAnimated(true, completion: nil)
        }
        
        print("email is \(emailText.text) password is \(passwordText.text)")
    }
    
    /*func fetchRegister() {
        Alamofire.request(
            .GET,
            "http://735d20b2.ngrok.io/register/\(emailText.text!)/\(passwordText.text!)",
            parameters: ["include_docs": "true"],
            encoding: .URL)
            .validate()
            .responseJSON { (response) -> Void in
                guard response.result.isSuccess else {
                    print("Error while fetching register: \(response.result.error)")
                    return
                }
                
                guard let value = response.result.value as? [String: AnyObject]
                    else {
                        print("didn't get anything")
                        return
                }
                print(value["success"]!)
        }
    }*/

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
