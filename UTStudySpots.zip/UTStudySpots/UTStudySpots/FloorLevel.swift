//
//  FloorLevel.swift
//  UTStudySpots
//
//  Created by Karla Reyes on 10/17/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit

class FloorLevel: UITableView {
    
    
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
