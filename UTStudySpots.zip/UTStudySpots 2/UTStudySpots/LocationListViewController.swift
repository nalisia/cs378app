//
//  LocationListViewController.swift
//  UTStudySpots
//
//  Created by Nalisia Greenleaf on 10/8/16.
//  Copyright © 2016 Nalisia Greenleaf. All rights reserved.
//

import UIKit
import CoreData

let textCellIdentifier = "TextCell"

var locations = ["Student Activity Center (SAC)",
                 "Flawn Academic Center (FAC)", "Perry-Castaneda Library (PCL)",
                 "Union Building (UNB)","Gates Dell Complex (GDC)",
                 "Robert Lee Moore Hall (RLM)", "Liberal Arts Building (CLA)",
                 "Robert A. Welch Hall (WEL)", "Norman Hackerman Building (NHB)",
                 "Student Services Building (SSB)"]

class LocationListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        tableView.delegate = self
        tableView.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func retrieveLocs() -> [NSManagedObject] {
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        
        
        
        let fetchRequest = NSFetchRequest(entityName:"UTPlace")
        var fetchedResults:[NSManagedObject]? = nil
        
        do {
            try fetchedResults = managedContext.executeFetchRequest(fetchRequest) as? [NSManagedObject]
        } catch {
            // If an error occurs
            let nserror = error as NSError
            NSLog("Unresolved error \(nserror), \(nserror.userInfo)")
            abort()
        }
        
        return(fetchedResults)!
        
    }
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return locations.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(textCellIdentifier, forIndexPath: indexPath)
        
        let row = indexPath.row
        let results = retrieveLocs()
        let utlocation = results[row]
        let name = utlocation.valueForKey("name")
        let acro = utlocation.valueForKey("acronym")
        let fullName:String? = "\(name!) (\(acro!))"
        cell.textLabel?.text = fullName
        cell.textLabel?.textColor = UIColor.orangeColor()
        
        // sets the cell pic
        var locs = ["SAC", "FAC", "PCL", "UNB", "GDC", "RLM", "CLA", "WEL", "NHB", "SSB"]
        for i in 0 ..< locs.count{
            if (acro as! String == locs[i]){
                let image = UIImage(named: locs[i])
                cell.imageView?.image = image
                cell.imageView?.frame = CGRectMake(0, 0, 32, 32)
                cell.imageView?.sizeToFit()
            }
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: true)
        
        let row = indexPath.row
        print(locations[row])
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     if  segue.identifier == "buildingSegue",
     let vc = segue.destinationViewController as? DisplayRatingsViewController,
     index = tableView.indexPathForSelectedRow?.row {
        vc.location = retrieveLocs()[index]
     }
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
